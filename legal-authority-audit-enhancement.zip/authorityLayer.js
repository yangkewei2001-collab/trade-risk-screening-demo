(function () {
  const authorityReferenceMap = {
    INCOTERMS_2020: {
      readableName: "Incoterms 2020",
      jurisdiction: "International trade / sale of goods",
      officialUrl: "https://iccwbo.org/business-solutions/incoterms-rules/incoterms-2020/",
      limitation: "Commercial rules incorporated by contract; they do not determine title, payment, governing law, dispute resolution, sanctions, or export control compliance."
    },
    CISG_UNCITRAL: {
      readableName: "United Nations Convention on Contracts for the International Sale of Goods (CISG)",
      jurisdiction: "International sale of goods",
      officialUrl: "https://uncitral.un.org/en/texts/salegoods/conventions/sale_of_goods/cisg",
      limitation: "The demo does not determine CISG applicability; it flags where governing law/CISG review may be needed."
    },
    NEW_YORK_CONVENTION: {
      readableName: "New York Convention on Recognition and Enforcement of Foreign Arbitral Awards",
      jurisdiction: "International arbitration enforcement",
      officialUrl: "https://uncitral.un.org/en/texts/arbitration/conventions/foreign_arbitral_awards",
      limitation: "The demo does not assess enforceability in any specific jurisdiction."
    },
    FATF_TBML_INDICATORS: {
      readableName: "FATF / Egmont Group Trade-Based Money Laundering Risk Indicators",
      jurisdiction: "AML / trade-based money laundering",
      officialUrl: "https://www.fatf-gafi.org/en/publications/Methodsandtrends/Trade-based-money-laundering-indicators.html",
      limitation: "Risk indicators are not proof of money laundering; further due diligence and manual verification are required."
    },
    UN_CONSOLIDATED_SANCTIONS_LIST: {
      readableName: "United Nations Security Council Consolidated List",
      jurisdiction: "UN sanctions",
      officialUrl: "https://main.un.org/securitycouncil/en/content/un-sc-consolidated-list",
      limitation: "The demo does not query the live UN list. Manual verification is required."
    },
    EU_SANCTIONS_MAP: {
      readableName: "EU Sanctions Map",
      jurisdiction: "EU restrictive measures",
      officialUrl: "https://www.sanctionsmap.eu/",
      limitation: "The demo does not query the live EU Sanctions Map. Manual verification is required."
    },
    UK_OFSI_FINANCIAL_SANCTIONS: {
      readableName: "UK OFSI Financial Sanctions Guidance",
      jurisdiction: "United Kingdom financial sanctions",
      officialUrl: "https://www.gov.uk/guidance/uk-financial-sanctions-guidance",
      limitation: "The demo does not screen live UK sanctions lists. Manual verification against current OFSI lists is required."
    },
    OFAC_COMPLIANCE_FRAMEWORK: {
      readableName: "OFAC Framework for Compliance Commitments",
      jurisdiction: "U.S. sanctions compliance",
      officialUrl: "https://ofac.treasury.gov/media/16331/download?inline=",
      limitation: "The demo does not screen live OFAC lists or determine sanctions exposure. Manual verification is required."
    },
    BIS_END_USE_END_USER_CONTROLS: {
      readableName: "BIS Guidance on End-User and End-Use Controls",
      jurisdiction: "U.S. export controls / EAR",
      officialUrl: "https://www.bis.gov/licensing/guidance-on-end-user-and-end-use-controls-and-us-person-controls",
      limitation: "The demo does not classify items, determine ECCNs, or determine license requirements."
    },
    UK_ECJU_EXPORT_CONTROLS: {
      readableName: "UK Strategic Export Controls Guidance",
      jurisdiction: "UK export controls",
      officialUrl: "https://www.gov.uk/guidance/export-controls-dual-use-items-software-and-technology-goods-for-torture-and-radioactive-sources",
      limitation: "The demo does not check UK control lists or determine licensing outcomes."
    },
    GDPR_SCC_EU_COMMISSION: {
      readableName: "European Commission Standard Contractual Clauses",
      jurisdiction: "EU/EEA personal data transfers under GDPR",
      officialUrl: "https://commission.europa.eu/law/law-topic/data-protection/international-dimension-data-protection/standard-contractual-clauses-scc_en",
      limitation: "The demo does not determine whether SCCs are sufficient for a specific transfer. Data protection review is required."
    },
    GDPR_SCC: {
      readableName: "European Commission Standard Contractual Clauses",
      jurisdiction: "EU/EEA personal data transfers under GDPR",
      officialUrl: "https://commission.europa.eu/law/law-topic/data-protection/international-dimension-data-protection/standard-contractual-clauses-scc_en",
      limitation: "Alias for GDPR_SCC_EU_COMMISSION. The demo does not determine whether SCCs are sufficient for a specific transfer."
    },
    PIPL_CROSS_BORDER_TRANSFER: {
      readableName: "China Personal Information Protection Law - Cross-border personal information transfer review",
      jurisdiction: "China / personal information cross-border transfer",
      officialUrl: "https://www.npc.gov.cn/",
      limitation: "The demo does not determine PIPL transfer mechanism sufficiency, security assessment requirements, certification requirements, or standard contract filing outcomes. Manual PRC data compliance review is required."
    },
    UK_BRIBERY_ACT_GUIDANCE: {
      readableName: "UK Bribery Act 2010 Guidance",
      jurisdiction: "United Kingdom anti-bribery compliance",
      officialUrl: "https://www.gov.uk/government/publications/bribery-act-2010-guidance",
      limitation: "The demo does not determine whether bribery occurred or whether UK jurisdiction applies."
    },
    FCPA_RESOURCE_GUIDE: {
      readableName: "DOJ/SEC Resource Guide to the U.S. Foreign Corrupt Practices Act",
      jurisdiction: "U.S. anti-corruption / foreign bribery",
      officialUrl: "https://www.justice.gov/criminal/criminal-fraud/file/1292051/download",
      limitation: "The demo does not assess FCPA jurisdiction, liability, or enforcement risk. Manual legal review is required."
    }
  };

  window.authorityReferenceMap = authorityReferenceMap;

  const sourceStore = () => ({ ...authorityReferenceMap, ...(typeof legalSources !== "undefined" ? legalSources : window.legalSources || {}) });
  const originalLoadRules = window.loadRules;

  window.loadRules = async function loadRulesWithLegalAuthority() {
    const loaded = await originalLoadRules();
    return normalizeRulesForAuthority(loaded);
  };

  window.normalizeRulesForAuthority = normalizeRulesForAuthority;
  window.getSourcesForRule = getSourcesForRule;
  window.formatLegalBasis = formatLegalBasis;
  window.formatAuthorityDetails = formatAuthorityDetails;

  function normalizeRulesForAuthority(ruleList) {
    return ruleList.map((rule) => ({
      ...rule,
      ruleVersion: rule.ruleVersion || rule.version || "v1.0",
      riskArea: rule.riskArea || rule.category || "Practical legal review",
      triggerCondition: rule.triggerCondition || `${rule.conditionField} ${rule.conditionOperator} ${rule.conditionValue}`,
      severity: rule.severity || rule.riskLevel,
      score: rule.score || riskScore(rule.riskLevel),
      sourceKeys: normalizeSourceKeys(rule.sourceKeys || []),
      legalRationale: rule.legalRationale || rule.reason || "Practical legal review rationale.",
      applicabilityLimits: rule.applicabilityLimits || "This demo flags a potential review point only. It does not determine whether the transaction is lawful or unlawful.",
      evidenceNeeded: rule.evidenceNeeded || ["Transaction documents", "Counterparty information", "Business rationale", "Relevant internal approval records"],
      recommendedAction: rule.recommendedAction || rule.reviewPoint || "Legal/compliance review recommended before relying on this result.",
      escalation: rule.escalation || "Escalate to qualified legal or compliance professionals where facts are incomplete or risk remains unclear.",
      manualVerificationRequired: rule.manualVerificationRequired !== undefined ? rule.manualVerificationRequired : true
    }));
  }

  function normalizeSourceKeys(keys) {
    const normalized = [...keys];
    if (normalized.includes("GDPR_SCC_EU_COMMISSION") && !normalized.includes("GDPR_SCC")) normalized.push("GDPR_SCC");
    return normalized;
  }

  function getSourcesForRule(rule) {
    const store = sourceStore();
    return (rule.sourceKeys || []).map((key) => {
      const source = store[key];
      if (!source) return null;
      return {
        key,
        title: source.title || source.readableName,
        institution: source.institution || source.readableName,
        authorityType: source.authorityType || "Authority reference",
        authorityLevel: source.authorityLevel || "Reference / guidance",
        jurisdictionOrScope: source.jurisdictionOrScope || source.jurisdiction,
        officialUrl: source.officialUrl,
        summary: source.summary || "Reference used for rule explainability.",
        relevanceToDemo: source.relevanceToDemo || "Used to explain why this risk indicator requires further legal or compliance review.",
        applicabilityLimits: source.applicabilityLimits || source.limitation || "Manual review is required."
      };
    }).filter(Boolean);
  }

  function formatLegalBasis(rule) {
    const sources = getSourcesForRule(rule);
    if (!sources.length) return "Practical legal review rationale; no specific legal source linked.";
    return sources.map((source) => `${source.key}: ${source.title} (${source.institution})`).join("; ");
  }

  function formatAuthorityDetails(rule) {
    return getSourcesForRule(rule).map((source) => ({
      sourceKey: source.key,
      title: source.title,
      institution: source.institution,
      jurisdictionOrScope: source.jurisdictionOrScope,
      authorityType: source.authorityType,
      authorityLevel: source.authorityLevel,
      relevanceToDemo: source.relevanceToDemo,
      applicabilityLimits: source.applicabilityLimits,
      officialUrl: source.officialUrl
    }));
  }

  window.renderTriggeredRisks = function renderTriggeredRisksWithAuthority(triggered) {
    const container = document.getElementById("triggeredRisks");
    container.innerHTML = "";

    if (triggered.length === 0) {
      const empty = document.createElement("div");
      empty.className = "risk-card low";
      empty.innerHTML = `
        <div class="risk-card-header">
          <strong>No preset risk triggered</strong>
          <span class="risk-level low">Low</span>
        </div>
        <div class="risk-detail-grid">
          <p><span>Reason:</span> The submitted information did not trigger the current preset screening rules.</p>
          <p><span>Suggested follow-up question:</span> Are all transaction documents complete and consistent?</p>
          <p><span>Suggested legal review point:</span> Keep standard contract, compliance, payment, and shipment records for future review.</p>
        </div>
      `;
      container.appendChild(empty);
      return;
    }

    triggered.forEach((risk) => {
      const card = document.createElement("article");
      card.className = `risk-card ${risk.riskLevel.toLowerCase()}`;
      card.innerHTML = `
        <div class="risk-card-header">
          <strong>${escapeHtml(risk.category)}</strong>
          <span class="risk-level ${risk.riskLevel.toLowerCase()}">${escapeHtml(risk.riskLevel)} | Score ${risk.calculatedScore}</span>
        </div>
        <div class="risk-detail-grid audit-grid">
          <p><span>Rule ID:</span> <code>${escapeHtml(risk.id)}</code></p>
          <p><span>Rule version:</span> ${escapeHtml(risk.ruleVersion || "v1.0")}</p>
          <p><span>Risk area:</span> ${escapeHtml(risk.riskArea)}</p>
          <p><span>Source keys:</span> ${renderSourceKeyBadges(risk.sourceKeys || [])}</p>
          <p><span>Legal rationale:</span> ${escapeHtml(risk.legalRationale)}</p>
          <p><span>Applicability limits:</span> ${escapeHtml(risk.applicabilityLimits)}</p>
          <p><span>Evidence needed:</span> ${escapeHtml((risk.evidenceNeeded || []).join("; "))}</p>
          <p><span>Recommended action:</span> ${escapeHtml(risk.recommendedAction)}</p>
          <p><span>Manual verification required:</span> ${risk.manualVerificationRequired ? "Yes" : "No"}</p>
        </div>
        <details class="legal-basis-details">
          <summary>Authority references and audit trail</summary>
          ${renderLegalBasisHtml(risk)}
        </details>
      `;
      container.appendChild(card);
    });
  };

  function renderLegalBasisHtml(rule) {
    const sources = getSourcesForRule(rule);
    const sourceHtml = sources.length ? sources.map((source) => `
      <li>
        <a href="${escapeHtml(source.officialUrl)}" target="_blank" rel="noopener noreferrer">${escapeHtml(source.key)} - ${escapeHtml(source.title)}</a>
        <span>Jurisdiction/scope: ${escapeHtml(source.jurisdictionOrScope)}</span>
        <span>Authority type: ${escapeHtml(source.authorityType)}</span>
        <span>Relevance: ${escapeHtml(source.relevanceToDemo)}</span>
        <span>Limitation: ${escapeHtml(source.applicabilityLimits)}</span>
      </li>
    `).join("") : `<li>Practical legal review rationale; no specific legal source linked.</li>`;
    return `
      <div class="legal-basis-copy">
        <p><strong>Trigger condition:</strong> ${escapeHtml(rule.triggerCondition)}</p>
        <p><strong>Legal basis/source keys:</strong> ${escapeHtml((rule.sourceKeys || []).join("; ") || "None linked")}</p>
        <p><strong>Escalation:</strong> ${escapeHtml(rule.escalation)}</p>
        <ul>${sourceHtml}</ul>
      </div>
    `;
  }

  function renderSourceKeyBadges(keys) {
    if (!keys.length) return "None linked";
    return keys.map((key) => `<code class="source-key-chip">${escapeHtml(key)}</code>`).join(" ");
  }

  window.buildBusinessChecklist = function buildBusinessChecklistWithEvidence(triggered) {
    const base = [
      "Have the identities and signing authority of the buyer, seller, payer, beneficial owners, and relevant payment parties been verified?",
      "Are the contract draft, purchase order, invoice, shipping documents, and payment records complete and consistent?",
      "Does the transaction require internal commercial, finance, compliance, or legal approval before execution?"
    ];
    return unique([...triggered.map((risk) => risk.followUpQuestion), ...triggered.flatMap((risk) => risk.evidenceNeeded || []), ...base]).slice(0, 14);
  };

  window.buildLegalReviewPoints = function buildLegalReviewPointsWithAuthority(triggered) {
    const base = [
      "Review whether contract terms match the actual transaction structure, payment flow, delivery process, and compliance obligations.",
      "Confirm that this rule-based result is reviewed by qualified legal professionals before being relied upon.",
      "Manual verification against current official lists/databases is required for sanctions, export control, AML, ownership, and data-transfer issues."
    ];
    return unique([...triggered.map((risk) => risk.recommendedAction || risk.reviewPoint), ...triggered.map((risk) => risk.escalation), ...base]).slice(0, 14);
  };

  const originalBuildChineseReport = window.buildChineseReport;
  const originalBuildEnglishSummary = window.buildEnglishSummary;

  window.buildChineseReport = function buildChineseReportWithAuthority(formData, triggered, totalScore, overall, checklist, legalPoints) {
    const base = originalBuildChineseReport(formData, triggered, totalScore, overall, checklist, legalPoints);
    const authoritySection = ["", "四、法律依据与审计字段", ...buildChineseAuthorityReportLines(triggered), ""].join("\n");
    return base.replace("\n\n四、业务追问清单", `${authoritySection}\n五、业务追问清单`)
      .replace("\n\n五、建议法务重点审查内容", "\n\n六、建议法务重点审查内容")
      .replace("\n\n六、免责声明", "\n\n七、免责声明")
      .replace("本工具仅用于交易前期法律与合规风险初筛，不构成正式法律意见。具体交易安排、合同条款及合规判断应由专业法律人员结合完整事实和适用法律进一步审查。", "本 Demo 是一个规则驱动的法律风险初筛原型，不提供法律意见，不判断交易是否合法，也不能替代具备资质的律师或合规人员审查。对于制裁、出口管制、反洗钱、公司受益所有权和数据跨境问题，必须基于最新官方数据库和适用地法律进行人工核查。");
  };

  window.buildEnglishSummary = function buildEnglishSummaryWithAuthority(formData, triggered, totalScore, overall, checklist, legalPoints) {
    const base = originalBuildEnglishSummary(formData, triggered, totalScore, overall, checklist, legalPoints);
    const authoritySection = ["", "4. Legal Basis, Source Keys, and Audit Fields", ...buildEnglishAuthorityReportLines(triggered), ""].join("\n");
    return base.replace("\n\n4. Follow-up Questions", `${authoritySection}\n5. Follow-up Questions`)
      .replace("\n\n5. Suggested Legal Review Points", "\n\n6. Suggested Legal Review Points")
      .replace("\n\n6. Disclaimer", "\n\n7. Disclaimer")
      .replace("This tool is for preliminary legal and compliance risk screening at the early stage of a transaction and does not constitute formal legal advice. The specific transaction structure, contract terms, and compliance assessment should be further reviewed by qualified legal professionals based on complete facts and applicable law.", "This demo is a rule-based legal risk triage prototype. It does not provide legal advice, does not determine whether a transaction is lawful or unlawful, and does not replace review by qualified legal or compliance professionals. For sanctions, export control, AML, company ownership, and data-transfer issues, manual verification against current official databases and applicable local law is required.");
  };

  function buildEnglishAuthorityReportLines(triggered) {
    if (!triggered.length) return ["No specific linked authority was triggered by the preset rules."];
    return triggered.flatMap((risk, index) => [
      `${index + 1}. Issue: ${risk.category}`,
      `   Rule ID: ${risk.id}`,
      `   Rule version: ${risk.ruleVersion || "v1.0"}`,
      `   Source keys: ${(risk.sourceKeys || []).join("; ") || "None linked"}`,
      `   Legal basis: ${formatLegalBasis(risk)}`,
      `   Legal rationale: ${risk.legalRationale}`,
      `   Applicability limits: ${risk.applicabilityLimits}`,
      `   Evidence needed: ${(risk.evidenceNeeded || []).join("; ")}`,
      `   Recommended action: ${risk.recommendedAction}`,
      `   Escalation: ${risk.escalation}`,
      `   Manual verification required: ${risk.manualVerificationRequired ? "Yes" : "No"}`,
      `   Authority details: ${formatAuthorityDetails(risk).map((source) => `${source.sourceKey} | ${source.jurisdictionOrScope} | ${source.officialUrl} | Limitation: ${source.applicabilityLimits}`).join(" || ") || "No mapped authority details"}`
    ]);
  }

  function buildChineseAuthorityReportLines(triggered) {
    if (!triggered.length) return ["当前预设规则未触发特定法律依据链接。"];
    return triggered.flatMap((risk, index) => [
      `${index + 1}. 风险事项：${risk.category}`,
      `   规则 ID：${risk.id}`,
      `   规则版本：${risk.ruleVersion || "v1.0"}`,
      `   sourceKeys：${(risk.sourceKeys || []).join("；") || "未链接"}`,
      `   对应法律依据：${formatLegalBasis(risk)}`,
      `   法律审查逻辑：${risk.legalRationale}`,
      `   适用边界：${risk.applicabilityLimits}`,
      `   需要补充核查的材料：${(risk.evidenceNeeded || []).join("；")}`,
      `   建议动作：${risk.recommendedAction}`,
      `   升级/转交：${risk.escalation}`,
      `   是否需要人工核查：${risk.manualVerificationRequired ? "是" : "否"}`
    ]);
  }

  document.addEventListener("DOMContentLoaded", renderAuthorityMatrix);

  function renderAuthorityMatrix() {
    const container = document.getElementById("authorityMatrixBody");
    if (!container) return;
    container.innerHTML = Object.entries(sourceStore()).map(([key, source]) => {
      const normalized = getSourcesForRule({ sourceKeys: [key] })[0];
      return `
        <tr>
          <td>${escapeHtml(normalized?.jurisdictionOrScope || source.jurisdictionOrScope || source.jurisdiction || "General legal/compliance reference")}</td>
          <td><a href="${escapeHtml(normalized?.officialUrl || source.officialUrl || "#")}" target="_blank" rel="noopener noreferrer">${escapeHtml(normalized?.title || source.title || source.readableName || key)}</a><br><span>${escapeHtml(normalized?.institution || source.institution || source.readableName || key)}</span><br><code>${escapeHtml(key)}</code></td>
          <td>${escapeHtml(normalized?.authorityType || source.authorityType || "Authority reference")}<br><span>${escapeHtml(normalized?.authorityLevel || source.authorityLevel || "Reference / guidance")}</span></td>
          <td>${escapeHtml(normalized?.relevanceToDemo || source.relevanceToDemo || "Used to explain linked risk indicators and review needs.")}</td>
          <td>${escapeHtml(normalized?.applicabilityLimits || source.applicabilityLimits || source.limitation || "Manual review is required.")}</td>
        </tr>
      `;
    }).join("");
  }

  function riskScore(level) {
    return { Low: 1, Medium: 2, High: 3 }[level] || 0;
  }
})();
